'''This Python file creates a database called asmis and the tables: patient_info, appointment and examinationreports
inside the database using the mysql.connector. It also creates dummy staff for users to use the asmis database 
and give them privileges, based on their jobs. A robot user is created to automatically insert new patient 
in the asmis_using file, to reducemthe privileges to a minimum.
This file should work fine in theory, but could never be tested with mysql.connector because it never worked.'''

import mysql.connector
from mysql.connector import Error


#Create the asmis database:
connection = mysql.connector.connect (host = "localhost",
                              user = "root",
                              passwd = "codio")
create_asmisdb = connection.cursor()
create_asmisdb.execute("CREATE DATABASE IF NOT EXISTS asmis;")

#Create the tables patient_info, appointment and examinationreports in the asmis database
create_patient_info = connection.cursor()
create_patient_info.execute("USE asmis; CREATE TABLE IF NOT EXISTS patient_info (PatientID INT unsigned not null auto_increment, Username VARCHAR (80), Firstname VARCHAR(40), Surname VARCHAR (40), Gender VARCHAR (7),Birthday DATE , Address VARCHAR (255),primary key (PatientID)) auto_increment=1;")
create_appointment = connection.cursor()
create_appointment.execute("USE asmis; CREATE TABLE IF NOT EXISTS appointment (PatientID INT unsigned not null auto_increment, Username VARCHAR (80), Firstname VARCHAR(40), Surname VARCHAR (40), Gender VARCHAR (7), Appointmentdate DATETIME, Doctor VARCHAR (40), foreign key (PatientID) references asmis.patient_info(PatientID));")
create_examinationreports = connection.cursor()
create_examinationreports.execute("USE asmis; CREATE TABLE IF NOT EXISTS examinationreports (PatientID INT unsigned not null auto_increment, Username VARCHAR (80), Firstname VARCHAR(40), Surname VARCHAR (40), Gender VARCHAR (7), Appointmentdate DATETIME, Doctor VARCHAR (40), Examinationreport TEXT ,foreign key (PatientID) references asmis.patient_info(PatientID));")

#Create dummy staff receptionist, doctor and adminassistant
create_user_receptionist = connection.cursor()
create_user_receptionist.execute("CREATE USER 'receptionist'@'localhost'identified by'123123';")
create_user_doctor = connection.cursor()
create_user_doctor.execute("CREATE USER 'doctor'@'localhost'identified by'234234';")
create_user_adminassistant = connection.cursor()
create_user_adminassistant.execute("CREATE USER 'adminassistant'@'localhost'identified by'345345';")

#Create a robot user for patient creating account
create_robotuser_createacc=connection.cursor()
create_robotuser_createacc.execute("CREATE USER 'createacc'@'%'identified by'strongpw';")



#Altering privileges of the dummy staff
#Privileges for receptionist
priv_receptionist = connection.cursor()
priv_receptionist.execute ("GRANT SELECT (Firstname,Surname,Gender,Appointmentdate,Doctor) ON asmis.appointment TO 'receptionist'@'localhost';")
priv_receptionist.execute ("GRANT INSERT (Firstname,Surname,Gender,Appointmentdate,Doctor) ON asmis.appointment TO 'receptionist'@'localhost';")
priv_receptionist.execute ("GRANT UPDATE (Firstname,Surname,Gender,Appointmentdate,Doctor) ON asmis.appointment TO 'receptionist'@'localhost';")


priv_receptionist.execute ("GRANT SELECT (Firstname,Surname,Gender,Birthday,Address) ON  asmis.patient_info TO 'receptionist'@'localhost';")
priv_receptionist.execute ("GRANT INSERT (Firstname,Surname,Gender,Birthday,Address) ON asmis.patient_info TO 'receptionist'@'localhost';")
priv_receptionist.execute ("GRANT UPDATE(Firstname,Surname,Gender,Birthday,Address) ON asmis.patient_info TO 'receptionist'@'localhost';")


#Privileges for doctor
priv_doctor = connection.cursor()
priv_doctor.execute ("GRANT SELECT (Firstname,Surname,Gender,Appointmentdate,Doctor) ON asmis.appointment TO 'doctor'@'localhost';")

priv_doctor.execute("GRANT SELECT (Firstname,Surname,Gender,Appointmentdate,Doctor,Examinationreport) ON asmis.examinationreports TO 'doctor'@'localhost';")
priv_doctor.execute("GRANT UPDATE (Examinationreport) ON asmis.examinationreports TO 'doctor'@'localhost';")

#Privileges for adminassistant
priv_adminassistant = connection.cursor()
priv_adminassistant.execute("GRANT SELECT ON mysql.tables_priv TO 'adminassistant'@'localhost';")
priv_adminassistant.execute("GRANT INSERT ON mysql.tables_priv TO 'adminassistant'@'localhost';")
priv_adminassistant.execute("GRANT UPDATE ON mysql.tables_priv TO 'adminassistant'@'localhost';")
priv_adminassistant.execute("GRANT DELETE ON mysql.tables_priv TO 'adminassistant'@'localhost';")

priv_adminassistant.execute("GRANT SELECT ON mysql.columns_priv TO 'adminassistant'@'localhost';")
priv_adminassistant.execute("GRANT INSERT ON mysql.columns_priv TO 'adminassistant'@'localhost';")
priv_adminassistant.execute("GRANT UPDATE ON mysql.columns_priv TO 'adminassistant'@'localhost';")
priv_adminassistant.execute("GRANT DELETE ON mysql.columns_priv TO 'adminassistant'@'localhost';")

priv_adminassistant.execute("GRANT SELECT (PatientID,Username) ON asmis.patient_info TO 'adminassistant'@'localhost';")
priv_adminassistant.execute("GRANT DELETE ON asmis.patient_info TO 'adminassistant'@'localhost';")

#Privileges for the robot user
priv_creatacc = connection.cursor()
priv_creatacc.execute("GRANT INSERT ON mysql.user TO 'createacc'@'%';")
priv_creatacc.execute("GRANT INSERT ON asmis.patient_info TO 'createacc'@'%';")
priv_creatacc.execute("GRANT INSERT ON asmis.appointment TO 'createacc'@'%';")
priv_creatacc.execute("GRANT INSERT ON asmis.examinationreports TO 'createacc'@'%';")


