'''This Python file should enable the use of the asmis database. However it is only possible to login and create a
patient user, but not to insert any informations about the patient in the tables. A working solution could be possibly
found in the using_asmis_sqlconnector.py file, but cannot be confirmed.'''

import MySQLdb



#login to asmis or create new account
print ("Welcome to Queens Medical Centre")
pageenter = input ("To login please enter 'login' to create a user please type 'create':")
print (pageenter)

#crete new user account
if pageenter=="create":
  connection_createacc = MySQLdb.connect (host = "localhost",
                              user = "createacc",
                              passwd = "strongpw")
  
  new_user = input ("Please enter your username:")
  new_password = input ("Please type enter password:")
  confirmpw = input ("Please confirm enter password:")
  if new_password == confirmpw:
    create_account = connection_createacc.cursor()
    create_account.execute("CREATE USER %s @'localhost'identified by %s;", (new_user,new_password))
    create_account.execute("INSERT INTO table asmis.patient_info (Username,Firstname,Surname,Gender,Birthday,Adress )VALUES (%s,NULL,NULL,NULL,NULL,NULL,NULL);",(new_user))
    create_account.execute("INSERT INTO table asmis.appointment (Username,Firstname,Surname,Gender,Appointmentdate,Doctor) VALUES (%s,NULL,NULL,NULL,NULL,NULL);",(new_user))
    create_account.execute("INSERT INSERT table asmis.examinationreports (Username,Firstname,Surname,Gender,Appointmentdate,doctor,Examinationreport) VALUES (%s,NULL,NULL,NULL,NULL,NULL,NULL);",(new_user))
    connection_createacc.commit()
    
    print ("Welcome"+new_user+"to the Queens Medical Centre. Your account was been succsessfully created. You can now login.")
    connection_createacc.close()
  else:
    print ("You typed tow different passwords.")
     


#login terminal
elif pageenter=="login":
#directing user to options based on the user-role  
  role_inp = input ("Please enter your correct role (patient, receptionist, doctor or adminassistant):")


  #allowing patient to input personal details or getting an appointment   
  if role_inp == "patient":
    loginusername = input ("please enter your username:")
    loginpassword = input ("please enter your password:")
    connection_user = MySQLdb.connect (host ="localhost",
                                    user = loginusername,
                                    passwd = loginpassword)
    print ("Hello " + loginusername +".")
    
    print ("If you have created a new account, please input your personal details first before you arrange an appointment. ")
    patient_nav = input("What do you want to do? For entering personal details type'personal_details'. For getting an appointment please type 'appointment':")
    if patient_nav == "personal_details" or "pd":
      
      #Inserting patient details into patient_info
      
      firstname_inp = input ("Please enter your firstname:")
      surname_inp = input ("Please enter your surname:")
      gender_inp = input ("Please enter your gernder:")
      birthday_inp = input ("please enter your Birthday:")
      adress_inp = input ("Please enter your Adress:")
      
      connection_createacc = MySQLdb.connect (host = "localhost",
                                                   user = "createacc",
                                                  passwd = "strongpw",
                                                  database = "asmis")
      connection_createacc.autocommit = True
      personal_datainp = connection_createacc.cursor()
      personal_datainp.execute ("INSERT INTO table asmis.patient_info WHERE Username=%s (Username,Firstname,Surname,Gender,Birthday,Adress ) VALUES (NULL,%s,%s,%s,%s;%s);",(loginusername, firstname_inp,surname_inp,gender_inp,birthday_inp,adress_inp))
      connection_createacc.commit()
    
      personal_datainp.execute ("INSERT INTO table asmis.appointment WHERE Username=%s (Username,Firstname,Surname,Gender,Appointmentdate,Doctor)VALUES (NULL,%s,%s,%s,NULL,NULL);",(loginusername,firstname_inp,surname_inp,gender_inp))
      connection_createacc.commit()
      personal_datainp.execute ("INSERT INTO table asmis.examinationreports WHERE Username=%s (Username,Firstname,Surname,Gender,Appointmentdate,Doctor,Examinationreport) VALUES (NULL,%s,%s,%s,NULL,NULL,NULL,NULL);",(loginusername,firstname_inp,surname_inp,gender_inp))
      connection_createacc.commit()
        
      connection_host.cursor.close()
        
       
    # let patient get an appointment    
    elif patient_nav == "appointment":
      get_appointmentdate = input ("Please enter a date for the appointment:")
      get_appointmentdoctor = input ("Please enter your preffered doctor:")
      
      connection_createacc = MySQLdb.connect (host = "localhost",
                                                   user = "createacc",
                                                  passwd = "strongpw",
                                                  database = "asmis")
      connection_createacc.autocommit = True
      appointment_input = connection_createacc.cursor()
      appointment_input.execute ("INSERT asmis.appointment WHERE Username=%s (Username,Firstname,Surname,Gender,Appointmentdate,Doctor)VALUES (NULL,NULL,NULL,NULL,%s,%s);)",(loginusername,get_appointmentdate,get_appointmentdoctor))
      connection_createacc.commit()
      connection_createacc.cursor.close()
    else: 
      print ("unknown command")
  
  
  
  #login receptionist
  elif role_inp == "receptionist":
    receptionist_username = input ("please enter your username:")
    receptionist_pw = input ("please enter your password:")
    connection_receptionist = MySQLdb.connect (host ="localhost",
                                    user = receptionist_username,
                                    passwd = receptionist_pw,
                                      database ="asmis")
    print ("Hello " + receptionist_username +".")
    
    
    receptionist_navigation = input ("To show the appointmens enter 'appointmens' to show patient details enter 'details'. If you want to make a new appointment for a patient enter 'newapp':")
    
    # Show all appointments of a patient with a given firstname and surname
    if receptionist_navigation == "appointments":
      appointment_firstname = input ("From which patient you want to get the appointments? Enter firstname:")
      appointment_surname = input ("Enter surname:")
      appointments_info = connection_receptionist.cursor()
      appointments_info.execute ("SELECT Firstname,Surname,Gender,Appointmentdate,Doctor FROM asmis.appointment WHERE Firstname=%s AND Surname=%;",appointment_firstname,appointment_surname)
      result = cursor.fetchall()
      for r in result:
        print(r)
      
      cursor.close()
      connection.close()
    
    #Show all patient details with a given firstname and surname
    elif receptionist_navigation == "detials":
      patient_firstname = input ("From which patient you want to get the details? Enter firstname:")
      patient_surname = input ("Enter surname:")
      patient_details = connection_receptionist.cursor()
      patient_details.execute ("SELECT Firstname,Surname,Gender,Birthday,Address FROM asmis.patient_info WHERE Firstname=%s AND Surname=%s;",patient_firstname,patient_surname)
  
  
    # Make a new appointment for a patient
    elif receptionist_navigation =="newapp":
      newapp_firstname = input ("Enter firstname of the patient:")
      newapp_surname = input ("Enter surname of the patient:")
      newapp_date = input ("When should be the appointment:")
      newapp_doctor = input ("Who should be the doctor:")
      newapp_create = connection_receptionist.cursor()
      newapp_create.execute ("UPDATE asmis.appointment SET Appointmentdate=%s , Doctor=%s WHERE Firstname=%s AND Surname =%s;",(newapp_date,newapp_doctor,newapp_firstname,newapp_surname))
      connection_receptionist.commit()
      cursor.close()
      connection.close()
    
    else:
      print("wrong command.")
    
    
  #login doctor
  elif role_inp == "doctor":
    doctor_username = input ("please enter your username:")
    doctor_pw = input ("please enter your password:")
    connection_doctor = MySQLdb.connect (host ="localhost",
                                    user = doctor_username,
                                    passwd = doctor_pw,
                                      database ="asmis")
    print ("Hello " + doctor_username +".")
    
    
    doctor_navigation = input ("If you want to see the appointments of a doctor enter 'doc_app', if you want to write an examinationreport enter 'report':")
    
    #Show the appointments of a doctor
    if doctor_navigation == "doc_app":
      choose_doc = input ("From which doctor should be the appointments displayed:")
      doctor_app = connection_doctor.cursor
      doctor_app.execute ("SELECT Firstname,Surname,Gender,Appointmentdate,Doctor FROM asmis.appointment WHERE Doctor=%s;",(choose_doc))
      result = cursor.fetchall()
      for r in result:
        print(r)
      cursor.close()
      connection.close()
    
    #Enter a new examinationreport
    elif doctor_navigation == "report":
      patient_reportf = input ("For which patient you want to enter the report? Enter firstname:")
      patient_reports = input ("Enter surname:")
      report_text = input ("Enter the examinationreport:")
      doctor_app.connection_doctor.cursor
      doctor_app.execute ("UPDATE asmis.examinationreport SET examinationreport=%s WHERE Firstname=%s AND Surname=%s;",(report_text,patient_reportf,patient_reports))
      connection_doctor.commit()
      cursor.close()
      connection.close() 
    
    else:
      print("wrong command.")
    
    
    #login adminassistant
  elif role_inp == "adminassistant":
    adminassis_username = input ("please enter your username:")
    adminassis_pw = input ("please enter your password:")
    connection_adminassistant = MySQLdb.connect (host ="localhost",
                                    user = adminassis_username,
                                    passwd = adminassis_pw)
                                      
    print ("Hello " + adminassis_username +".")
    adminassistant_navigation = input ("If you want to delete a patient enter 'delete' if you want to grant a user privileges enter 'grant':")
    
    #Delete a patient from patient_info table
    if adminassistant_navigation == "delete":
      patient_id = input ("Which patient you want to delete? Enter PatientID")
      patient_uname = input ("To confirm the right patient enter the Username:")
      admin_del.connection_adminassistant.cursor
      admin_del.execute("DELETE FROM asmis.patient_info WHERE PatientID=%s AND Username=%s;",(patient_id,patient_uname))
      connection_adminassistant.commit()
      cursor.close()
      connection.close() 
    
    
    # Grant a user privileges for a table
    elif adminassistant_navigation == "grant":
      username_grant = input ("Which user do you want to grant privileges? Enter username:")
      grant_def = input ("Which privileges to you want to give the user?")
      grant_table = input ("To which tabel shoud the privileges be given?")
      admin_grant.connection_adminassistant.cursor
      admin_grant.execute("GRANT %s ON %s TO %s@'localhost';",(grant_def,grant_table,username_grant))
      connection_adminassistant.commit()
      cursor.close()
      connection.close() 
    

    
  else: 
    print ("unknown command, please try again.")

  
else: 
  print("unknown command, please try again.")

print ("you logged out. Have a nice day!")